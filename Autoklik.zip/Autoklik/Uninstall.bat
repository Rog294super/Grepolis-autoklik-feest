@echo off
echo Autoklik Uninstaller
echo.
echo Dit verwijdert Autoklik van je computer.
echo Alle bestanden in de installatiemap worden verwijderd, inclusief configuratie.
echo Controleer of je belangrijke bestanden hebt in de installatiemap voordat je doorgaat.
echo LET OP: Deze actie kan niet ongedaan worden gemaakt!
echo.
pause
echo.
echo Verwijderen...
set "install_dir=%~dp0"
if "%install_dir:~-1%"=="\" set "install_dir=%install_dir:~0,-1%"
cd /d "%install_dir%\.."
rmdir /s /q "%install_dir%" 2>nul
if exist "%USERPROFILE%\Desktop\Autoklik.lnk" del "%USERPROFILE%\Desktop\Autoklik.lnk" 2>nul
echo.
echo Autoklik is verwijderd.
pause
